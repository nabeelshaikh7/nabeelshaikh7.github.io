    <div class="menu">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="premium-hosting.php">Premium Hosting</a></li>
          <li><a href="free-hosting-signup.php">Signup for Free Hosting</a></li>
          <li><a href="about-free-hosting.php">About Free Hosting</a></li>
          <li><a href="http://cpanel.<? echo "$yourdomain" ;?>">Login</a></li>
        </ul>
      </div>
